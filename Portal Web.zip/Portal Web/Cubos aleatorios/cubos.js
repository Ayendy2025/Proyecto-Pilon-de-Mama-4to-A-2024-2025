const datosCubos = [
    { titulo: "Cubo 1", descripcion: "Descripción 1", imagen: "https://via.placeholder.com/150", color: "#e57373" },
    { titulo: "Cubo 2", descripcion: "Descripción 2", imagen: "https://via.placeholder.com/150", color: "#f06292" },
    { titulo: "Cubo 3", descripcion: "Descripción 3", imagen: "https://via.placeholder.com/150", color: "#ba68c8" },
    { titulo: "Cubo 4", descripcion: "Descripción 4", imagen: "https://via.placeholder.com/150", color: "#9575cd" },
    { titulo: "Cubo 5", descripcion: "Descripción 5", imagen: "https://via.placeholder.com/150", color: "#7986cb" },
    { titulo: "Cubo 6", descripcion: "Descripción 6", imagen: "https://via.placeholder.com/150", color: "#64b5f6" },
    { titulo: "Cubo 7", descripcion: "Descripción 7", imagen: "https://via.placeholder.com/150", color: "#4fc3f7" },
    { titulo: "Cubo 8", descripcion: "Descripción 8", imagen: "https://via.placeholder.com/150", color: "#4dd0e1" },
    { titulo: "Cubo 9", descripcion: "Descripción 9", imagen: "https://via.placeholder.com/150", color: "#4db6ac" },
    { titulo: "Cubo 10", descripcion: "Descripción 10", imagen: "https://via.placeholder.com/150", color: "#81c784" },
    { titulo: "Cubo 11", descripcion: "Descripción 11", imagen: "https://via.placeholder.com/150", color: "#aed581" },
    { titulo: "Cubo 12", descripcion: "Descripción 12", imagen: "https://via.placeholder.com/150", color: "#dce775" },
    { titulo: "Cubo 13", descripcion: "Descripción 13", imagen: "https://via.placeholder.com/150", color: "#fff176" },
    { titulo: "Cubo 14", descripcion: "Descripción 14", imagen: "https://via.placeholder.com/150", color: "#ffd54f" },
    { titulo: "Cubo 15", descripcion: "Descripción 15", imagen: "https://via.placeholder.com/150", color: "#ffb74d" }
];

function obtenerCubosAleatorios(lista, cantidad) {
    const seleccionados = [];
    const usados = new Set();

    while (seleccionados.length < cantidad) {
        const indice = Math.floor(Math.random() * lista.length);
        if (!usados.has(indice)) {
            usados.add(indice);
            seleccionados.push(lista[indice]);
        }
    }
    return seleccionados;
}

const contenedor = document.getElementById("contenedor-cubos");
const cubosAleatorios = obtenerCubosAleatorios(datosCubos, 3);

cubosAleatorios.forEach(cubo => {
    const div = document.createElement("div");
    div.className = "cubo";
    div.style.backgroundColor = cubo.color;
    div.innerHTML = `
        <img src="${cubo.imagen}" alt="${cubo.titulo}">
        <h3>${cubo.titulo}</h3>
        <p>${cubo.descripcion}</p>
    `;
    contenedor.appendChild(div);
});
