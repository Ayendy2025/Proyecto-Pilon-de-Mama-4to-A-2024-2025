
const datos = [
    { titulo: "Cubo 1", descripcion: "Descripción del cubo 1", imagen: "https://via.placeholder.com/80?text=1" },
    { titulo: "Cubo 2", descripcion: "Descripción del cubo 2", imagen: "https://via.placeholder.com/80?text=2" },
    { titulo: "Cubo 3", descripcion: "Descripción del cubo 3", imagen: "https://via.placeholder.com/80?text=3" },
    { titulo: "Cubo 4", descripcion: "Descripción del cubo 4", imagen: "https://via.placeholder.com/80?text=4" },
    { titulo: "Cubo 5", descripcion: "Descripción del cubo 5", imagen: "https://via.placeholder.com/80?text=5" },
    { titulo: "Cubo 6", descripcion: "Descripción del cubo 6", imagen: "https://via.placeholder.com/80?text=6" },
    { titulo: "Cubo 7", descripcion: "Descripción del cubo 7", imagen: "https://via.placeholder.com/80?text=7" },
    { titulo: "Cubo 8", descripcion: "Descripción del cubo 8", imagen: "https://via.placeholder.com/80?text=8" },
    { titulo: "Cubo 9", descripcion: "Descripción del cubo 9", imagen: "https://via.placeholder.com/80?text=9" },
    { titulo: "Cubo 10", descripcion: "Descripción del cubo 10", imagen: "https://via.placeholder.com/80?text=10" },
    { titulo: "Cubo 11", descripcion: "Descripción del cubo 11", imagen: "https://via.placeholder.com/80?text=11" },
    { titulo: "Cubo 12", descripcion: "Descripción del cubo 12", imagen: "https://via.placeholder.com/80?text=12" },
    { titulo: "Cubo 13", descripcion: "Descripción del cubo 13", imagen: "https://via.placeholder.com/80?text=13" },
    { titulo: "Cubo 14", descripcion: "Descripción del cubo 14", imagen: "https://via.placeholder.com/80?text=14" },
    { titulo: "Cubo 15", descripcion: "Descripción del cubo 15", imagen: "https://via.placeholder.com/80?text=15" },
];

function colorAleatorio() {
    const r = Math.floor(Math.random() * 200);
    const g = Math.floor(Math.random() * 200);
    const b = Math.floor(Math.random() * 200);
    return `rgb(${r}, ${g}, ${b})`;
}

const contenedor = document.getElementById("contenedor");
const seleccionados = datos.sort(() => Math.random() - 0.5).slice(0, 15);

seleccionados.forEach(item => {
    const cubo = document.createElement("div");
    cubo.classList.add("cubo");
    cubo.style.backgroundColor = colorAleatorio();
    cubo.innerHTML = `
        <img src="\${item.imagen}" alt="\${item.titulo}">
        <strong>\${item.titulo}</strong>
        <p>\${item.descripcion}</p>
    `;
    contenedor.appendChild(cubo);
});
