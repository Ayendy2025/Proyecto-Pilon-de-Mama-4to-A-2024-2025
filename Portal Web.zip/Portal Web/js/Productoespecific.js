document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("modalImagen");
    const img = document.getElementById("imgProducto");
    const modalImg = document.getElementById("imgEnGrande");
    const cerrar = document.getElementById("cerrarModal");

    img.onclick = function () {
        modal.style.display = "block";
        modalImg.src = this.src;
    }

    cerrar.onclick = function () {
        modal.style.display = "none";
    }

    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    }
});


const datosCubos = [
    { titulo: "Cubo 1", descripcion: "Descripción 1", imagen: "IMG/PRODUCTOS/CUBO.jpg", color: "#e57373", href: "archivos/cubo-1.html" },
    { titulo: "Cubo 2", descripcion: "Descripción 2", imagen: "https://via.placeholder.com/150", color: "#f06292", href: "archivos/cubo-2.html" },
    { titulo: "Cubo 3", descripcion: "Descripción 3", imagen: "https://via.placeholder.com/150", color: "#ba68c8", href: "archivos/cubo-3.html" },
    { titulo: "Cubo 4", descripcion: "Descripción 4", imagen: "https://via.placeholder.com/150", color: "#9575cd", href: "archivos/cubo-4.html" },
    { titulo: "Cubo 5", descripcion: "Descripción 5", imagen: "https://via.placeholder.com/150", color: "#7986cb", href: "archivos/cubo-5.html" },
    { titulo: "Cubo 6", descripcion: "Descripción 6", imagen: "https://via.placeholder.com/150", color: "#64b5f6", href: "archivos/cubo-6.html" },
    { titulo: "Cubo 7", descripcion: "Descripción 7", imagen: "https://via.placeholder.com/150", color: "#4fc3f7", href: "archivos/cubo-7.html" },
    { titulo: "Cubo 8", descripcion: "Descripción 8", imagen: "https://via.placeholder.com/150", color: "#4dd0e1", href: "archivos/cubo-8.html" },
    { titulo: "Cubo 9", descripcion: "Descripción 9", imagen: "https://via.placeholder.com/150", color: "#4db6ac", href: "archivos/cubo-9.html" },
    { titulo: "Cubo 10", descripcion: "Descripción 10", imagen: "https://via.placeholder.com/150", color: "#81c784", href: "archivos/cubo-10.html" },
    { titulo: "Cubo 11", descripcion: "Descripción 11", imagen: "https://via.placeholder.com/150", color: "#aed581", href: "archivos/cubo-11.html" },
    { titulo: "Cubo 12", descripcion: "Descripción 12", imagen: "https://via.placeholder.com/150", color: "#dce775", href: "archivos/cubo-12.html" },
    { titulo: "Cubo 13", descripcion: "Descripción 13", imagen: "https://via.placeholder.com/150", color: "#fff176", href: "archivos/cubo-13.html" },
    { titulo: "Cubo 14", descripcion: "Descripción 14", imagen: "https://via.placeholder.com/150", color: "#ffd54f", href: "archivos/cubo-14.html" },
    { titulo: "Cubo 15", descripcion: "Descripción 15", imagen: "https://via.placeholder.com/150", color: "#ffb74d", href: "archivos/cubo-15.html" }
];

function obtenerCubosAleatorios(lista, cantidad) {
    const seleccionados = [];
    const usados = new Set();

    while (seleccionados.length < cantidad) {
        const indice = Math.floor(Math.random() * lista.length);
        if (!usados.has(indice)) {
            usados.add(indice);
            seleccionados.push(lista[indice]);
        }
    }
    return seleccionados;
}

const contenedor = document.getElementById("contenedor-cubos");
const cubosAleatorios = obtenerCubosAleatorios(datosCubos, 3); // Cambiado a 15 para mostrar más cubos

cubosAleatorios.forEach(cubo => {
    const div = document.createElement("div");
    div.className = "cubo";
    div.style.backgroundColor = cubo.color;

    const enlace = document.createElement("a");
    enlace.href = cubo.href; // Usa el href definido en datosCubos
    enlace.target = "_self"; // Abre en la misma ventana

    enlace.innerHTML = `
        <img src="${cubo.imagen}" alt="${cubo.titulo}">
        <h3>${cubo.titulo}</h3>
        <p>${cubo.descripcion}</p>
    `;

    div.appendChild(enlace);
    contenedor.appendChild(div);
});