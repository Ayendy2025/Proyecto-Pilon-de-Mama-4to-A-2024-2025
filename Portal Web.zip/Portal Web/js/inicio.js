const productos = {
  "Jambergue": "Producto 1.html",
  "Chimi": "Producto 2.html",
  "Sandwich": "Producto 3.html",
  "Clubsadwi": "Producto 4.html",
  "Yaroa": "Producto 5.html",
  "Salchipapa": "Producto 6.html",
  "Papa con queso": "Producto 7.html",
  "Carne salada": "Producto 8.html",
  "Longaniza con papas": "Producto 9.html",
  "Chuleta con tostones": "Producto 10.html",
  "Quesadilla": "Producto 11.html",
  "Tostada": "Producto 12.html",
  "Jodo": "Producto 13.html",
  "Jugos": "Producto 14.html",
  "Refrescos": "Producto 15.html"
};

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("search-button").addEventListener("click", function (event) {
    event.preventDefault();
    const query = document.getElementById("search-input").value.trim().toLowerCase();

    if (productos[query]) {
      window.location.href = productos[query];
    } else {
      window.location.href = "Error-busqueda-Producto.html";
    }
  });
});

// Función para botón "Ir al Principio"
function irAlPrincipio() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
