let indiceDiapositiva = 1;
mostrarDiapositiva(indiceDiapositiva);

function cambiarDiapositiva(n) {
  mostrarDiapositiva(indiceDiapositiva += n);
}

function diapositivaActual(n) {
  mostrarDiapositiva(indiceDiapositiva = n);
}

function mostrarDiapositiva(n) {
  let i;
  let diapositivas = document.getElementsByClassName("diapositiva");
  let puntos = document.getElementsByClassName("punto");
  if (n > diapositivas.length) { indiceDiapositiva = 1 }
  if (n < 1) { indiceDiapositiva = diapositivas.length }
  for (i = 0; i < diapositivas.length; i++) {
    diapositivas[i].style.display = "none";
  }
  for (i = 0; i < puntos.length; i++) {
    puntos[i].className = puntos[i].className.replace(" activo", "");
  }
  diapositivas[indiceDiapositiva - 1].style.display = "block";
  puntos[indiceDiapositiva - 1].className += " activo";
}

// Carrusel automático
setInterval(() => {
  cambiarDiapositiva(1);
}, 3000);






