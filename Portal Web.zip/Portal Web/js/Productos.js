const producto = document.getElementById('producto');

producto.addEventListener('mouseenter', () => {
    producto.style.backgroundColor = '#e0e0e0';
    producto.style.transform = 'scale(1.05)';
});

producto.addEventListener('mouseleave', () => {
    producto.style.backgroundColor = '#f0f0f0';
    producto.style.transform = 'scale(1)';
});


